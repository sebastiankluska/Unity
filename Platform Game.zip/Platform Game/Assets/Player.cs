﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    //move
    public float moveSpeed;

    //jump
    public Vector3 jump;
    public float jumpForce = 2.5f;

    public bool isGrounded;
    Rigidbody rb;

    //reset
    Vector3 startPos;
    public Quaternion startRot;

	// Use this for initialization
	void Start () {

        //move
        moveSpeed = 3f;

        //jump
        rb = GetComponent<Rigidbody>();
        jump = new Vector3(0f, 2.5f, 0f);

        //reset
        startPos = transform.position;
        startRot = transform.rotation;
	}
    //jump
    private void OnCollisionStay(Collision collision)
    {
        isGrounded = true;
    }

    // Update is called once per frame
    void Update () {

        //move
        transform.Translate(moveSpeed*Input.GetAxis("Horizontal") * Time.deltaTime, 0f, 0f);

        //jump
        if(Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.AddForce(jump * jumpForce, ForceMode.Impulse);
            isGrounded = false;
        }

        //reset
        if (Input.GetKeyDown(KeyCode.R))
        {
            transform.position = startPos;
            transform.localRotation = startRot;
        }
	}
}
